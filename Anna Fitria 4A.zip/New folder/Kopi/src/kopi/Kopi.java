
package kopi;


public class Kopi {

   
    public static void main(String[] args) {
        MenuKopi kopiEspresso = new MenuKopi();
        
        kopiEspresso.namaKopi = "Cappucino";
        kopiEspresso.jenisKopi= "Kopi dingin dan panas";
        kopiEspresso.hargaKopi = 20000;
        
        MenuKopi kopiAmericano = new MenuKopi();
        kopiAmericano.namaKopi = "Latte";
        kopiAmericano.jenisKopi = "Kopi Panas";
        kopiAmericano.hargaKopi = 25000;
        
        System.out.println(kopiEspresso.namaKopi);
        
        System.out.println(kopiAmericano.namaKopi);
        
        System.out.println(kopiEspresso.hargaKopi + kopiAmericano.hargaKopi);
    }
    
}
