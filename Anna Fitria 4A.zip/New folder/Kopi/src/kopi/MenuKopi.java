
package kopi;

public class MenuKopi {
    String namaKopi;
    String jenisKopi;
    double hargaKopi;
    
    
    public void kopiLangka(){
        this.namaKopi = "Robusta";
    }
    
}
